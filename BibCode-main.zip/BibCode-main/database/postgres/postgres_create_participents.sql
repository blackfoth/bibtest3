-- Table: public.participents

-- DROP TABLE IF EXISTS public.participents;

CREATE TABLE IF NOT EXISTS public.participents
(
    "ID" SERIAL PRIMARY KEY,
    "FirstName" VARCHAR(45),
    "LastName" VARCHAR(45),
    "Age" INTEGER
);

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.participents
    OWNER to chris;