-- Table: public.partrace

-- DROP TABLE IF EXISTS public.partrace;

CREATE TABLE IF NOT EXISTS public.partrace
(
    "ParticipentID" integer NOT NULL,
    "RaceID" integer NOT NULL,
    "BibNum" character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT "PartRacePK" PRIMARY KEY ("ParticipentID", "RaceID"),
    CONSTRAINT "ParticipentID_FK" FOREIGN KEY ("ParticipentID")
        REFERENCES public.participents ("ID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "RaceID_FK" FOREIGN KEY ("RaceID")
        REFERENCES public.race ("ID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.partrace
    OWNER to chris;