-- Table: public.race

-- DROP TABLE IF EXISTS public.race;

CREATE TABLE IF NOT EXISTS public.race
(
    "ID" SERIAL PRIMARY KEY,
    "Title" VARCHAR(45) NOT NULL,
    "Date" DATE NOT NULL,
    "StartTime" TIME WITHOUT TIME ZONE NOT NULL,
    "Description" VARCHAR(255)
);
TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.race
    OWNER to postgres;